// image files for animations
const dino_still_image = new Image();
const dino_run_1_image = new Image();
const dino_run_2_image = new Image();

dino_still_image.src = '../resources/dino_still.png';
dino_run_1_image.src = '../resources/dino_run_1.png';
dino_run_2_image.src = '../resources/dino_run_2.png';

// player class
class Player {
  constructor(x, y, width, height, velocityX = 0, velocityY = 0) {

  }

  update(game) {

  }

  draw(game) {

  }
}

export default Player;
