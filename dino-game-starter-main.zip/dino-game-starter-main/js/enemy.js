// image files for animations
const bird_still_image = new Image();
bird_still_image.src = '../resources/bird_still.png';

class Enemy {
  constructor(width, height, velocityX = 0, velocityY = 0, x = undefined) {

  }

  randomizePosition() {

  }

  update(game, player) {

  }

  draw(game) {

  }
}

export default Enemy;
